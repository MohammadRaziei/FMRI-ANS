# emacs: -*- mode: python; py-indent-offset: 4; indent-tabs-mode: nil -*-
# vi: set ft=python sts=4 ts=4 sw=4 et:
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ##
#
#   Majority of the code in this submodule is borrowed from SciPy.
#   SciPy: Copyright 1999- by various SciPy developers
#          License   BSD-3-clause
#
#   For the rest of the code -- see COPYING file distributed along
#   with the PyMVPA package for the copyright and license terms.
#
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ##
"""Some functionality which was fixed in later versions of SciPy."""
